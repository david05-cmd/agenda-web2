<?php
/* ════════════════════════════════════════════════════════
   registrar.php · AgendaWeb (kit de rescate P2–P3)
   Formulario (P2) + procesamiento (P3) en un solo archivo.
   Cada TODO te dice en qué paso de la guía se completa.
   ════════════════════════════════════════════════════════ */

// Función de ayuda: limpia un texto antes de mostrarlo en la página.
// Evita que alguien "inyecte" HTML o JavaScript (ataque XSS).
// Ejemplo:  echo e($titulo);
function e(?string $valor): string
{
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

// TODO Paso 7 · Recibir y validar los datos del formulario

// Declaración inicial de variables para los campos
$titulo = '';
$fecha = '';
$categoria = '';

// Arreglo para almacenar los mensajes de error por campo
$errores = [];

// Procesamos el formulario únicamente si el método de la petición es POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Leemos los valores enviados limpios de espacios al inicio/final
    $titulo = trim($_POST['titulo'] ?? '');
    $fecha = trim($_POST['fecha'] ?? '');
    $categoria = trim($_POST['categoria'] ?? '');

    // 1. Validación del campo: Título
    if ($titulo === '') {
        $errores['titulo'] = 'El título del evento es obligatorio.';
    } elseif (mb_strlen($titulo) > 120) {
        $errores['titulo'] = 'El título no puede superar los 120 caracteres.';
    }

    // 2. Validación del campo: Fecha
    if ($fecha === '') {
        $errores['fecha'] = 'La fecha del evento es obligatoria.';
    } else {
        // Verificamos que sea una fecha válida con el formato Y-m-d
        $fechaObjeto = DateTime::createFromFormat('Y-m-d', $fecha);
        if (!$fechaObjeto || $fechaObjeto->format('Y-m-d') !== $fecha) {
            $errores['fecha'] = 'La fecha ingresada no es válida.';
        }
    }

    // 3. Validación del campo: Categoría
    $categoriasValidas = ['trabajo', 'personal', 'estudio', 'ocio'];
    if ($categoria === '') {
        $errores['categoria'] = 'Debes seleccionar una categoría.';
    } elseif (!in_array($categoria, $categoriasValidas, true)) {
        $errores['categoria'] = 'La categoría seleccionada no es válida.';
    }
}

// TODO Paso 8 · Guardar en MySQL (solo si no hubo errores)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($errores)) {
    // 1. Conectar a la base de datos (requiere que exista conexion.php)
    require_once 'conexion.php';

    // 2. Preparar la consulta SQL (para evitar inyecciones SQL)
    $stmt = $mysqli->prepare("INSERT INTO eventos (titulo, fecha, categoria) VALUES (?, ?, ?)");
    
    // 3. Vincular los datos (las tres 'sss' indican que son tres textos/strings)
    $stmt->bind_param('sss', $titulo, $fecha, $categoria);

    // 4. Ejecutar la consulta
    if ($stmt->execute()) {
        // 5. Redirigir a index.php con la bandera de éxito
        header('Location: index.php?ok=1');
        exit;
    } else {
        $errores['general'] = "Hubo un error al guardar en la base de datos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- TODO Paso 5 · Pega aquí el <link> de Google Fonts de tu marca -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500&family=Plus+Jakarta+Sans:wght@600;700&display=swap" rel="stylesheet">
    <title>Nuevo evento · AgendaWeb</title>
</head>
<body>
<div class="card">
    <h1 class="card__title">Nuevo evento</h1>
    <p class="card__meta">AgendaWeb de David Moreno Orozco</p>

    <!-- TODO Paso 6 · Pega aquí tu <form> -->
    <form method="post" action="">
        <!-- Campo Título -->
        <div class="form-group">
            <label class="form-label" for="titulo">Título</label>
            <input 
                type="text" 
                class="form-input <?= isset($errores['titulo']) ? 'is-invalid' : '' ?>" 
                name="titulo" 
                id="titulo" 
                maxlength="120" 
                value="<?= e($titulo) ?>"
                required
            >
            <?php if (isset($errores['titulo'])): ?>
                <p class="form-error"><?= e($errores['titulo']) ?></p>
            <?php endif; ?>
        </div>

        <!-- Campo Fecha -->
        <div class="form-group">
            <label class="form-label" for="fecha">Fecha</label>
            <input 
                type="date" 
                class="form-input <?= isset($errores['fecha']) ? 'is-invalid' : '' ?>" 
                name="fecha" 
                id="fecha" 
                value="<?= e($fecha) ?>"
                required
            >
            <?php if (isset($errores['fecha'])): ?>
                <p class="form-error"><?= e($errores['fecha']) ?></p>
            <?php endif; ?>
        </div>

        <!-- Campo Categoría -->
        <div class="form-group">
            <label class="form-label" for="categoria">Categoría</label>
            <select 
                class="form-select <?= isset($errores['categoria']) ? 'is-invalid' : '' ?>" 
                name="categoria" 
                id="categoria" 
                required
            >
                <option value="" <?= $categoria === '' ? 'selected' : '' ?>>— Elige una —</option>
                <option value="trabajo" <?= $categoria === 'trabajo' ? 'selected' : '' ?>>Trabajo</option>
                <option value="personal" <?= $categoria === 'personal' ? 'selected' : '' ?>>Personal</option>
                <option value="estudio" <?= $categoria === 'estudio' ? 'selected' : '' ?>>Estudio</option>
                <option value="ocio" <?= $categoria === 'ocio' ? 'selected' : '' ?>>Ocio / Deporte</option>
            </select>
            <?php if (isset($errores['categoria'])): ?>
                <p class="form-error"><?= e($errores['categoria']) ?></p>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn-primary">Guardar evento</button>
    </form>

    <p class="card__link"><a href="index.php">Ver mis eventos</a></p>
</div>
</body>
</html>